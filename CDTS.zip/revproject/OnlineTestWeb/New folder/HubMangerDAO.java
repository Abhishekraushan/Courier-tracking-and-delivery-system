package dao;

import java.sql.*;

import beans.Track;

import com.mysql.jdbc.Driver;
public class HubMangerDAO {
	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	public void getDBConnection() throws SQLException{
		
		Driver driver=new Driver();
		DriverManager.registerDriver(driver);
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdts", "root", "");
		System.out.println("Connection Created");
	}
	public void closeDBConnection() throws SQLException{
		conn.close();
		System.out.println("Connection Closed");
	}
	public String validation(String uid,String pwd) throws SQLException
	{
		pst=conn.prepareStatement("select * from login where userid=? and password=?");
		pst.setString(1, uid);
		pst.setString(2, pwd);
		ResultSet rs=pst.executeQuery();
		if(rs.next())
			return (rs.getString(1));
		else 
			return null;
	}
	public void addTrackInfo(Track log) throws SQLException{
		pst=conn.prepareStatement("insert into trackingdetails values(?,?,?,?)");
		pst.setString(1, log.getTrackId());
		pst.setString(2, log.getPosition());
		pst.setString(3, log.getArrival());
		pst.setString(4, log.getDeparture());
		
		pst.executeUpdate();
	}
	
}